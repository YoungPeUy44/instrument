/*
Navicat MySQL Data Transfer

Source Server         : yutshida
Source Server Version : 50525
Source Host           : localhost:3306
Source Database       : loginslabhosxp

Target Server Type    : MYSQL
Target Server Version : 50525
File Encoding         : 65001

Date: 2020-01-08 15:11:13
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `determination_bc5300`
-- ----------------------------
DROP TABLE IF EXISTS `determination_bc5300`;
CREATE TABLE `determination_bc5300` (
  `DeterID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DeterName` varchar(45) NOT NULL,
  `DeterCode` varchar(10) DEFAULT NULL,
  `DeterMin` float NOT NULL DEFAULT '0',
  `DeterMax` float NOT NULL DEFAULT '0',
  `DeterOperate` varchar(1) NOT NULL DEFAULT '0',
  `DeterUnit` varchar(45) NOT NULL DEFAULT '0',
  `HOSItemCode` varchar(100) NOT NULL DEFAULT '0',
  `DeterFactor` int(11) DEFAULT NULL,
  `Enable` tinyint(1) NOT NULL DEFAULT '0',
  `DeterPoint` float DEFAULT NULL,
  `job_instruments_id` int(11) DEFAULT NULL,
  `DeterSpecial` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`DeterID`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=tis620;

-- ----------------------------
-- Records of determination_bc5300
-- ----------------------------
INSERT INTO `determination_bc5300` VALUES ('1', 'WBC', null, '0', '0', '0', '0', '398', '3', '0', null, '28', null);
INSERT INTO `determination_bc5300` VALUES ('2', 'BAS#', null, '0', '0', '0', '0', '0', '0', '0', null, '28', null);
INSERT INTO `determination_bc5300` VALUES ('3', 'BAS%', null, '0', '0', '0', '0', '425', '0', '0', '0', '28', null);
INSERT INTO `determination_bc5300` VALUES ('4', 'NEU#', null, '0', '0', '0', '0', '0', '0', '0', null, '28', null);
INSERT INTO `determination_bc5300` VALUES ('5', 'NEU%', null, '0', '0', '0', '0', '427', '0', '0', '0', '28', null);
INSERT INTO `determination_bc5300` VALUES ('6', 'EOS#', null, '0', '0', '0', '0', '0', '0', '0', null, '28', null);
INSERT INTO `determination_bc5300` VALUES ('7', 'EOS%', null, '0', '0', '0', '0', '423', '0', '0', '0', '28', null);
INSERT INTO `determination_bc5300` VALUES ('8', 'LYM#', null, '0', '0', '0', '0', '0', '0', '0', null, '28', null);
INSERT INTO `determination_bc5300` VALUES ('9', 'LYM%', null, '0', '0', '0', '0', '422', '0', '0', '0', '28', null);
INSERT INTO `determination_bc5300` VALUES ('10', 'MON#', null, '0', '0', '0', '0', '0', '0', '0', null, '28', null);
INSERT INTO `determination_bc5300` VALUES ('11', 'MON%', null, '0', '0', '0', '0', '424', '0', '0', '0', '28', null);
INSERT INTO `determination_bc5300` VALUES ('12', '*ALY#', null, '0', '0', '0', '0', '0', '0', '0', null, '28', null);
INSERT INTO `determination_bc5300` VALUES ('13', '*ALY%', null, '0', '0', '0', '0', '0', '0', '0', null, '28', null);
INSERT INTO `determination_bc5300` VALUES ('14', '*LIC#', null, '0', '0', '0', '0', '0', '0', '0', null, '28', null);
INSERT INTO `determination_bc5300` VALUES ('15', '*LIC%', null, '0', '0', '0', '0', '0', '0', '0', null, '28', null);
INSERT INTO `determination_bc5300` VALUES ('16', 'RBC', null, '0', '0', '0', '0', '399', '0', '0', null, '28', null);
INSERT INTO `determination_bc5300` VALUES ('17', 'HGB', null, '0', '0', '0', '0', '309', '0', '0', null, '28', null);
INSERT INTO `determination_bc5300` VALUES ('18', 'MCV', null, '0', '0', '0', '0', '401', '0', '0', null, '28', null);
INSERT INTO `determination_bc5300` VALUES ('19', 'MCH', null, '0', '0', '0', '0', '402', '0', '0', null, '28', null);
INSERT INTO `determination_bc5300` VALUES ('20', 'MCHC', null, '0', '0', '0', '0', '403', '0', '0', null, '28', null);
INSERT INTO `determination_bc5300` VALUES ('21', 'RDW-CV', null, '0', '0', '0', '0', '404', '0', '0', null, '28', null);
INSERT INTO `determination_bc5300` VALUES ('22', 'RDW-SD', null, '0', '0', '0', '0', '0', '0', '0', null, '28', null);
INSERT INTO `determination_bc5300` VALUES ('23', 'HCT', null, '0', '0', '0', '0', '308', '0', '0', null, '28', null);
INSERT INTO `determination_bc5300` VALUES ('24', 'PLT', null, '0', '0', '0', '0', '400', '3', '0', null, '28', null);
INSERT INTO `determination_bc5300` VALUES ('25', 'MPV', null, '0', '0', '0', '0', '0', '0', '0', null, '28', null);
INSERT INTO `determination_bc5300` VALUES ('26', 'PDW', null, '0', '0', '0', '0', '0', '0', '0', null, '28', null);
INSERT INTO `determination_bc5300` VALUES ('27', 'PCT', null, '0', '0', '0', '0', '0', '0', '0', null, '28', null);
INSERT INTO `determination_bc5300` VALUES ('28', 'WBC Histogram. BMP', null, '0', '0', '0', '0', '400', null, '0', null, '28', null);
INSERT INTO `determination_bc5300` VALUES ('29', 'RBC Histogram. BMP', null, '0', '0', '0', '0', '308', null, '0', null, '28', null);
INSERT INTO `determination_bc5300` VALUES ('30', 'PLT Histogram. BMP', null, '0', '0', '0', '0', '404', null, '0', null, '28', null);
INSERT INTO `determination_bc5300` VALUES ('31', 'WBC DIFF Scattergram. BMP', null, '0', '0', '0', '0', '403', null, '0', null, '28', null);
